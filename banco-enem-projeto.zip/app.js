"use strict";

/* ============================== Domínio ============================== */

const AREAS = {
  CN: ["Ciências da Natureza", "Física, Química, Biologia"],
  MT: ["Matemática", "e suas Tecnologias"],
  CH: ["Ciências Humanas", "História, Geografia, Filosofia, Sociologia"],
  LC: ["Linguagens", "Português, Literatura, Línguas, Artes"],
};

const APL = { regular: "Regular", ppl: "PPL", reaplicacao: "Reaplicação", digital: "Digital" };
const SIT = { todas: "Todas", nao: "Não respondidas", resp: "Respondidas", ok: "Acertadas", bad: "Erradas" };
const HKEY = "banco-enem:hist";

const $ = document.getElementById("app");
let Q = [];
let TX = null; // taxonomia: áreas → matérias → tópicos (taxonomy.json)
let IX = { sub: {}, top: {} }; // índices por id
let S = { area: "CN", n: 10, modo: "conteudo", materia: null, topico: null, f: {} };
let T = null;
let tick = null;
let H = readHist();

/* ============================== Helpers ============================== */

function h(t, a, ...k) {
  const e = document.createElement(t);
  for (const [x, v] of Object.entries(a || {})) {
    if (x.startsWith("on")) e.addEventListener(x.slice(2), v);
    else if (x === "class") e.className = v;
    else if (x.startsWith("aria-") && typeof v === "boolean") e.setAttribute(x, String(v));
    else if (v !== false && v != null) e.setAttribute(x, v === true ? "" : v);
  }
  for (const c of k.flat()) if (c != null) e.append(c);
  return e;
}

function mount(...n) {
  $.replaceChildren(...n.flat());
  $.classList.remove("in");
  void $.offsetWidth;
  $.classList.add("in");
  $.focus({ preventScroll: true });
  scrollTo(0, 0);
}

function shuffle(a) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// Enunciado: linha em branco separa parágrafos; quebra simples é mantida
// (poemas, listas). Figuras entram por ![alt](url).
function rich(t) {
  const w = h("div", { class: "enun" });
  String(t || "")
    .split(/!\[[^\]]*\]\(([^)]+)\)/)
    .forEach((x, i) => {
      if (i % 2)
        w.append(
          h("img", { class: "q", src: x, alt: "Imagem do enunciado", loading: "lazy" })
        );
      else
        x.split(/\n{2,}/).forEach((p) => {
          if (p.trim()) w.append(h("p", null, p.trim()));
        });
    });
  return w;
}

const imgs = (q) =>
  (q.imagens || []).map((u) =>
    h("img", { class: "q", src: u, alt: "Imagem da questão", loading: "lazy" })
  );

const altImg = (src) =>
  h("img", {
    class: "q alt-img",
    src,
    alt: "Alternativa em imagem",
    loading: "lazy",
  });

// Alternativa: texto, "img:<url>" ou texto com ![alt](url) no meio.
const altc = (t) =>
  t.startsWith("img:")
    ? altImg(t.slice(4))
    : /!\[[^\]]*\]\(/.test(t)
      ? h(
          "span",
          { class: "alt-mix" },
          t.split(/!\[[^\]]*\]\(([^)]+)\)/).map((x, i) => (i % 2 ? altImg(x) : x.trim() || null))
        )
      : t;

const fmt = (s) =>
  String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0");


/* ============================== Carga ================================ */

const getJSON = (u) =>
  fetch(u, { cache: "no-cache" }).then((r) => {
    if (!r.ok) throw new Error("HTTP " + r.status);
    return r.json();
  });

function load() {
  const tx = getJSON("taxonomy.json").catch(() => null);
  getJSON("questions.json")
    .then((d) => {
      if (!Array.isArray(d) || !d.length) throw new Error("banco vazio");
      return tx.then((t) => boot(d, t));
    })
    .catch(() => tx.then((t) => pickFile(t)));
}

/* Liga banco e taxonomia. Cada questão aponta para área, matéria e tópico;
   se os três não baterem com a taxonomia, a questão fica fora das telas de
   conteúdo (continua no simulado aleatório da área) e conta como revisão. */
function boot(d, t) {
  Q = d;
  TX = t && Array.isArray(t.areas) ? t : null;
  IX = { sub: {}, top: {} };
  for (const a of TX ? TX.areas : [])
    for (const s of a.subjects) {
      IX.sub[s.id] = { ...s, area: a.id };
      for (const x of s.topics) IX.top[x.id] = { ...x, area: a.id, materia: s.id };
    }
  for (const q of Q) q._ok = !!q.topico && consistent(q);
  home();
}

function consistent(q) {
  const t = IX.top[q.topico];
  return !!t && t.area === q.area && (!q.materia || q.materia === t.materia);
}

function pickFile(t) {
  mount(
    h("div", { class: "top" }, h("span", { class: "brand" }, "Banco ENEM")),
    h("h1", null, "Banco ENEM"),
    h(
      "p",
      { class: "lead" },
      "Não consegui carregar questions.json ao lado desta página. Sirva o site por um servidor (por exemplo o GitHub Pages) ou escolha o arquivo manualmente."
    ),
    h(
      "label",
      { class: "f" },
      "Arquivo de questões",
      h("input", {
        type: "file",
        accept: ".json,application/json",
        onchange: (e) => {
          const f = e.target.files[0];
          if (!f) return;
          f.text()
            .then((x) => {
              const d = JSON.parse(x);
              if (!Array.isArray(d) || !d.length) throw new Error("vazio");
              boot(d, t);
            })
            .catch(() => alert("Não consegui ler esse arquivo."));
        },
      })
    )
  );
}

/* ====================== Histórico do estudante ====================== */

// Fica só neste navegador. Sem localStorage o app funciona igual, sem progresso.
function readHist() {
  try {
    return JSON.parse(localStorage.getItem(HKEY)) || {};
  } catch {
    return {};
  }
}

function saveHist() {
  try {
    localStorage.setItem(HKEY, JSON.stringify(H));
  } catch {
    /* armazenamento indisponível: progresso só nesta sessão */
  }
}

/* ========================= Questões únicas ========================== */

// Questões equivalentes em outro caderno apontam para a original em
// `equivale`; anuladas não entram em simulado nem em contagem de únicas.
const canon = (q) => q.equivale || q.id;
const usable = (q) => !q.anulada;

function uniq(list) {
  const seen = new Set();
  return list.filter((q) => {
    if (!usable(q) || seen.has(canon(q))) return false;
    seen.add(canon(q));
    return true;
  });
}

const inArea = (a) => uniq(Q.filter((q) => q.area === a));
const inSub = (s) => uniq(Q.filter((q) => q._ok && IX.top[q.topico].materia === s));
const inTop = (t) => uniq(Q.filter((q) => q._ok && q.topico === t));
const subsOf = (a) => (TX ? (TX.areas.find((x) => x.id === a) || {}).subjects || [] : []);

function sit(q) {
  const r = H[canon(q)];
  return r ? (r.ok ? "ok" : "bad") : "nao";
}

const num = (n) => n.toLocaleString("pt-BR");
const plural = (n, um, varios) => num(n) + " " + (n === 1 ? um : varios);

/* =============================== Home ================================ */

function home() {
  clearInterval(tick);
  if (T) T.live = false;
  S = { ...S, materia: null, topico: null };

  const pool = inArea(S.area);
  const avail = pool.length;
  const pend = Q.filter((q) => q.area === S.area && usable(q) && !q._ok).length;

  const modos = h(
    "div",
    { class: "chips", role: "group", "aria-label": "Tipo de simulado" },
    [
      ["conteudo", "Por conteúdo"],
      ["aleatorio", "Simulado aleatório"],
    ].map(([k, n]) =>
      h(
        "button",
        {
          class: "chip mode",
          type: "button",
          "aria-pressed": S.modo === k,
          onclick: () => {
            S.modo = k;
            home();
          },
        },
        n
      )
    )
  );

  const aleatorio = [
    h(
      "div",
      null,
      h("div", { id: "nl" }, "Quantidade de questões"),
      h(
        "div",
        { class: "chips", role: "group", "aria-labelledby": "nl" },
        [5, 10, 25, 45].map((n) =>
          h(
            "button",
            {
              class: "chip",
              type: "button",
              "aria-pressed": S.n === n,
              onclick: () => {
                S.n = n;
                home();
              },
            },
            n
          )
        )
      )
    ),
    h(
      "p",
      { class: "note avail" },
      avail ? avail + " questões disponíveis neste filtro." : "Nenhuma questão neste filtro."
    ),
    h(
      "div",
      null,
      h(
        "button",
        {
          class: "btn primary",
          disabled: !avail,
          onclick: () => start(shuffle(pool.slice()).slice(0, S.n), home),
        },
        "Fazer simulado"
      )
    ),
  ];

  const subs = subsOf(S.area);
  const conteudo = [
    h("h3", { id: "ml" }, "Matérias"),
    subs.length
      ? h(
          "ul",
          { class: "list", "aria-labelledby": "ml" },
          subs.map((s) => {
            const n = inSub(s.id).length;
            return h(
              "li",
              null,
              h(
                "button",
                { class: "item sub", type: "button", onclick: () => materia(s.id) },
                h("span", { class: "item-name" }, s.nome),
                h(
                  "span",
                  { class: "item-meta" },
                  plural(s.topics.length, "tópico", "tópicos") + " · " + plural(n, "questão", "questões")
                )
              )
            );
          })
        )
      : h("p", { class: "note" }, "Lista de conteúdos indisponível. Use o simulado aleatório."),
    pend
      ? h(
          "p",
          { class: "note pend" },
          plural(pend, "questão desta área ainda aguarda", "questões desta área ainda aguardam") +
            " classificação por tópico e por enquanto só aparece no simulado aleatório."
        )
      : null,
  ];

  mount(
    h("div", { class: "top" }, h("span", { class: "brand" }, "Banco ENEM")),
    h("h1", null, "Treine com as provas do ENEM."),
    h(
      "p",
      { class: "lead" },
      num(uniq(Q).length) +
        " questões do ENEM, separadas por área e conteúdo. Você só vê o gabarito quando terminar."
    ),
    h(
      "div",
      {
        class: "tabs",
        role: "tablist",
        "aria-label": "Área do conhecimento",
        onkeydown: (e) => {
          const tabs = [...$.querySelectorAll(".tab")];
          const idx = tabs.findIndex((t) => t.getAttribute("aria-selected") === "true");
          let next = -1;
          if (e.key === "ArrowRight") next = (idx + 1) % tabs.length;
          else if (e.key === "ArrowLeft") next = (idx - 1 + tabs.length) % tabs.length;
          else if (e.key === "Home") next = 0;
          else if (e.key === "End") next = tabs.length - 1;
          if (next < 0) return;
          e.preventDefault();
          tabs[next].click();
        },
      },
      Object.entries(AREAS).map(([k, [n]]) =>
        h(
          "button",
          {
            id: "tab-" + k,
            class: "tab",
            role: "tab",
            type: "button",
            "aria-selected": k === S.area,
            "aria-controls": "setup",
            tabindex: k === S.area ? 0 : -1,
            onclick: () => {
              S = { ...S, area: k };
              home();
              document.getElementById("tab-" + k)?.focus();
            },
          },
          n
        )
      )
    ),
    h(
      "section",
      {
        class: "panel",
        id: "setup",
        role: "tabpanel",
        "aria-labelledby": "tab-" + S.area,
      },
      h("h2", null, AREAS[S.area][0]),
      h("p", { class: "note" }, AREAS[S.area][1]),
      modos,
      S.modo === "aleatorio" ? aleatorio : conteudo
    ),
    h(
      "footer",
      null,
      "A nota é uma estimativa simplificada, não a nota oficial do INEP."
    )
  );
}

/* ============================= Matéria =============================== */

const back = (txt, fn) =>
  h("button", { class: "btn back", type: "button", onclick: fn }, "‹ " + txt);

function materia(id) {
  clearInterval(tick);
  if (T) T.live = false;
  const s = IX.sub[id];
  S = { ...S, materia: id, topico: null };

  mount(
    h("div", { class: "top" }, back(AREAS[s.area][0], home)),
    h("p", { class: "eyebrow" }, AREAS[s.area][0]),
    h("h1", null, s.nome),
    h(
      "p",
      { class: "lead" },
      plural(s.topics.length, "grande tópico", "grandes tópicos") +
        " · " +
        plural(inSub(id).length, "questão classificada", "questões classificadas")
    ),
    h(
      "ul",
      { class: "list topics", "aria-label": "Grandes tópicos de " + s.nome },
      s.topics.map((t) => {
        const qs = inTop(t.id);
        const done = qs.filter((q) => H[canon(q)]).length;
        return h(
          "li",
          null,
          h(
            "button",
            { class: "item top-item", type: "button", onclick: () => topico(t.id) },
            h("span", { class: "item-name" }, t.nome),
            h(
              "span",
              { class: "item-meta" },
              qs.length
                ? plural(qs.length, "questão", "questões") + (done ? " · " + done + " respondidas" : "")
                : "Sem questões ainda"
            )
          )
        );
      })
    )
  );
}

/* ========================= Grande tópico ============================ */

function topico(id) {
  clearInterval(tick);
  if (T) T.live = false;
  const t = IX.top[id];
  const s = IX.sub[t.materia];
  if (S.topico !== id) S.f = {};
  S = { ...S, materia: s.id, topico: id };

  const all = inTop(id);
  const anul = Q.filter((q) => q._ok && q.topico === id && q.anulada).length;
  const f = { ano: "", apl: "", sit: "todas", ...S.f };
  const list = all.filter(
    (q) =>
      (!f.ano || String(q.ano) === f.ano) &&
      (!f.apl || (q.aplicacao || "") === f.apl) &&
      (f.sit === "todas" ||
        (f.sit === "resp" ? sit(q) !== "nao" : sit(q) === f.sit))
  );

  const nOk = all.filter((q) => sit(q) === "ok").length;
  const nBad = all.filter((q) => sit(q) === "bad").length;
  const nResp = nOk + nBad;

  const anos = {};
  for (const q of all) anos[q.ano] = (anos[q.ano] || 0) + 1;
  const anosK = Object.keys(anos).sort();
  const apls = [...new Set(all.map((q) => q.aplicacao || ""))].sort();
  const max = Math.max(1, ...Object.values(anos));

  const sel = (key, label, opts) =>
    h(
      "label",
      { class: "f" },
      label,
      h(
        "select",
        {
          "data-f": key,
          onchange: (e) => {
            S.f = { ...f, [key]: e.target.value };
            topico(id);
            document.querySelector('select[data-f="' + key + '"]')?.focus();
          },
        },
        opts.map(([v, n]) => h("option", { value: v, selected: f[key] === v }, n))
      )
    );

  mount(
    h("div", { class: "top" }, back(s.nome, () => materia(s.id))),
    h("p", { class: "eyebrow" }, AREAS[t.area][0] + " · " + s.nome),
    h("h1", null, t.nome),
    h("p", { class: "lead" }, t.desc),
    h(
      "div",
      { class: "stats" },
      h("div", null, h("b", { id: "n-uni" }, String(all.length)), h("span", null, "questões únicas")),
      h("div", null, h("b", null, String(nResp)), h("span", null, "respondidas")),
      h("div", null, h("b", null, String(all.length - nResp)), h("span", null, "não respondidas")),
      h("div", null, h("b", null, String(nOk)), h("span", null, "acertadas")),
      h("div", null, h("b", null, String(nBad)), h("span", null, "erradas"))
    ),
    all.length
      ? h(
          "div",
          { class: "learn" },
          h(
            "div",
            {
              class: "prog",
              role: "progressbar",
              "aria-valuemin": "0",
              "aria-valuemax": String(all.length),
              "aria-valuenow": String(nOk),
              "aria-label": "Progresso de aprendizagem: questões acertadas",
            },
            h("i", { style: "transform:scaleX(" + nOk / all.length + ")" })
          ),
          h(
            "p",
            { class: "note" },
            "Progresso: " + nOk + " de " + all.length + " acertadas" +
              (nResp ? " · aproveitamento de " + Math.round((100 * nOk) / nResp) + "% nas respondidas" : "") +
              "."
          )
        )
      : null,
    anul
      ? h("p", { class: "note" }, plural(anul, "questão anulada fica", "questões anuladas ficam") + " fora dos simulados.")
      : null,
    anosK.length
      ? h(
          "section",
          { class: "dist", "aria-labelledby": "dl" },
          h("h3", { id: "dl" }, "Distribuição por ano"),
          h(
            "ul",
            { class: "rows" },
            anosK.map((a) =>
              h(
                "li",
                { class: "row" },
                h("span", null, "ENEM " + a),
                h("span", { class: "row-bar", "aria-hidden": "true" }, h("i", { style: "transform:scaleX(" + anos[a] / max + ")" })),
                h("b", null, String(anos[a]))
              )
            )
          )
        )
      : null,
    all.length
      ? h(
          "div",
          { class: "filters" },
          sel("ano", "Ano", [["", "Todos os anos"], ...anosK.map((a) => [a, "ENEM " + a])]),
          sel("apl", "Aplicação", [
            ["", "Todas as aplicações"],
            ...apls.filter((a) => a !== "" || apls.length > 1).map((a) => [a, APL[a] || (a ? a : "Não informada")]),
          ]),
          sel("sit", "Situação", Object.entries(SIT))
        )
      : null,
    h(
      "p",
      { class: "note", id: "n-fil", role: "status" },
      all.length
        ? plural(list.length, "questão", "questões") + " neste filtro."
        : "Ainda não há questões classificadas neste tópico."
    ),
    list.length
      ? h(
          "div",
          null,
          h(
            "button",
            { class: "btn primary", onclick: () => start(shuffle(list.slice()), () => topico(id)) },
            "Resolver " + plural(list.length, "questão", "questões")
          )
        )
      : null,
    h(
      "ol",
      { class: "qlist", "aria-label": "Questões do tópico" },
      list.map((q, j) => {
        const st = sit(q);
        return h(
          "li",
          null,
          h(
            "button",
            {
              class: "qcard",
              type: "button",
              onclick: () => start(list.slice(), () => topico(id), j),
            },
            h(
              "span",
              { class: "qcard-head" },
              h(
                "span",
                { class: "meta" },
                "ENEM " + q.ano +
                  (q.aplicacao ? " · " + (APL[q.aplicacao] || q.aplicacao) : "") +
                  (q.numero ? " · Questão " + q.numero : "") +
                  (q.lang ? " · " + (q.lang === "ingles" ? "Inglês" : "Espanhol") : "")
              ),
              h(
                "span",
                { class: "tag " + (st === "ok" ? "ok" : st === "bad" ? "bad" : "nil") },
                st === "ok" ? "Acertou" : st === "bad" ? "Errou" : "Não respondida"
              )
            ),
            h("span", { class: "qcard-text" }, snippet(q.enunciado))
          )
        );
      })
    )
  );
}

function snippet(t) {
  const x = String(t || "").replace(/!\[[^\]]*\]\([^)]+\)/g, "[figura]").replace(/\s+/g, " ").trim();
  return x.length > 180 ? x.slice(0, 177).trimEnd() + "…" : x;
}

/* ============================= Simulado ============================== */

// qs já vem na ordem da prova; `back` é a tela para onde o estudante volta.
function start(qs, back = home, i = 0) {
  T = { qs, ans: {}, i, t0: Date.now(), back, live: true };
  clearInterval(tick);
  tick = setInterval(() => {
    const e = document.getElementById("tm");
    if (e) e.textContent = fmt(Math.floor((Date.now() - T.t0) / 1000));
  }, 1000);
  test();
}

function test() {
  const q = T.qs[T.i];
  const n = T.qs.length;
  const done = Object.keys(T.ans).length;

  mount(
    h(
      "div",
      { class: "bar" },
      h(
        "div",
        { class: "bar-row" },
        h("span", null, "Questão " + (T.i + 1) + " de " + n),
        h(
          "span",
          { class: "timer", id: "tm", role: "timer", "aria-label": "Tempo decorrido" },
          fmt(Math.floor((Date.now() - T.t0) / 1000))
        )
      ),
      h(
        "div",
        {
          class: "prog",
          role: "progressbar",
          "aria-valuemin": "0",
          "aria-valuemax": String(n),
          "aria-valuenow": String(done),
          "aria-label": "Progresso do simulado",
        },
        h("i", { style: "transform:scaleX(" + done / n + ")" })
      )
    ),    h(
      "div",
      { class: "q-top" },
      h(
        "p",
        { class: "meta" },
        (AREAS[q.area] ? AREAS[q.area][0] : q.area) +
          (q._ok ? " · " + IX.sub[IX.top[q.topico].materia].nome : "") +
          (q.lang ? " · " + (q.lang === "ingles" ? "Inglês" : "Espanhol") : "")
      ),
      h(
        "span",
        { class: "q-year", "aria-label": "Ano da prova: ENEM " + q.ano },
        "ENEM " + q.ano
      )
    ),
    rich(q.enunciado),
    imgs(q),
    h(
      "fieldset",
      { class: "alts" },
      h("legend", { class: "skip" }, "Alternativas"),
      Object.entries(q.alts).map(([l, t]) =>
        h(
          "label",
          { class: "alt" },
          h("input", {
            type: "radio",
            name: "a",
            value: l,
            checked: T.ans[q.id] === l,
            onchange: () => {
              T.ans[q.id] = l;
              paint();
            },
          }),
          h("span", { class: "bub", "aria-hidden": "true" }, l),
          h("span", null, altc(t))
        )
      )
    ),
    h(
      "div",
      { class: "nav" },
      h(
        "button",
        { class: "btn", disabled: T.i === 0, onclick: () => { T.i--; test(); } },
        "Anterior"
      ),
      T.i < n - 1
        ? h("button", { class: "btn primary", onclick: () => { T.i++; test(); } }, "Próxima")
        : h("button", { class: "btn primary", onclick: finish }, "Finalizar simulado")
    ),
    h(
      "div",
      { class: "grid", role: "group", "aria-label": "Ir para a questão" },
      T.qs.map((x, j) =>
        h(
          "button",
          {
            class: "dot" + (T.ans[x.id] ? " on" : ""),
            "aria-current": j === T.i,
            "aria-label":
              "Questão " + (j + 1) + (T.ans[x.id] ? ", respondida" : ", em branco"),
            onclick: () => {
              T.i = j;
              test();
            },
          },
          j + 1
        )
      )
    )
  );
}

function paint() {
  const n = T.qs.length;
  const done = Object.keys(T.ans).length;
  const bar = document.querySelector(".prog");
  if (bar) {
    bar.setAttribute("aria-valuenow", String(done));
    bar.querySelector("i").style.transform = "scaleX(" + done / n + ")";
  }
  const dot = document.querySelectorAll(".dot")[T.i];
  if (dot) dot.classList.add("on");
}

/* ============================== Nota TRI ============================= */

function tri(items) {
  let num = 0;
  let den = 0;
  for (let t = -4; t <= 4; t += 0.05) {
    let L = Math.exp((-t * t) / 2);
    for (const [q, ok] of items) {
      const a = q.a || 1;
      const b = q.b ?? 0;
      const c = q.c ?? 0.2;
      const p = c + (1 - c) / (1 + Math.exp(-1.7 * a * (t - b)));
      L *= ok ? p : 1 - p;
    }
    num += t * L;
    den += L;
  }
  return Math.round(500 + 100 * (num / den));
}

function confirmDialog(msg) {
  return new Promise((resolve) => {
    const done = (v) => {
      document.removeEventListener("keydown", onKey, true);
      dlg.close();
      dlg.remove();
      resolve(v);
    };
    const onKey = (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        done(false);
      }
    };
    const cancel = h("button", { class: "btn", onclick: () => done(false) }, "Continuar prova");
    const ok = h(
      "button",
      { class: "btn primary", onclick: () => done(true) },
      "Finalizar mesmo assim"
    );
    const dlg = h(
      "dialog",
      { class: "modal", "aria-labelledby": "md-title" },
      h("h2", { id: "md-title" }, "Ainda há questões em branco"),
      h("p", { class: "note" }, msg),
      h("div", { class: "modal-actions" }, cancel, ok)
    );
    dlg.addEventListener("cancel", (e) => {
      e.preventDefault();
      done(false);
    });
    document.body.append(dlg);
    document.addEventListener("keydown", onKey, true);
    dlg.showModal();
    ok.focus();
  });
}

function finish() {
  const blank = T.qs.length - Object.keys(T.ans).length;
  if (!blank) return closeExam();
  confirmDialog(
    blank === 1
      ? "1 questão sem resposta. Em branco conta como erro na nota."
      : blank + " questões sem resposta. Em branco conta como erro na nota."
  ).then((yes) => {
    if (yes) closeExam();
  });
}

function closeExam() {
  clearInterval(tick);
  T.live = false;
  // Guarda a última tentativa de cada questão respondida (em branco não conta).
  for (const q of T.qs)
    if (T.ans[q.id]) H[canon(q)] = { r: T.ans[q.id], ok: T.ans[q.id] === q.gab, t: Date.now() };
  saveHist();
  T.secs = Math.floor((Date.now() - T.t0) / 1000);
  T.hits = T.qs.filter((q) => T.ans[q.id] === q.gab).length;
  T.blank = T.qs.length - Object.keys(T.ans).length;
  T.nota = tri(T.qs.map((q) => [q, T.ans[q.id] === q.gab]));
  result();
}

/* ============================= Resultado ============================= */

function result() {
  mount(
    h("div", { class: "top" }, h("span", { class: "brand" }, "Banco ENEM")),
    h("p", { class: "meta" }, "Nota estimada"),
    h("div", { class: "score" }, T.nota),
    h(
      "div",
      { class: "stats" },
      h("div", null, h("b", null, T.hits + " de " + T.qs.length), h("span", null, "acertos")),
      h("div", null, h("b", null, fmt(T.secs)), h("span", null, "tempo total")),
      T.blank
        ? h("div", null, h("b", null, String(T.blank)), h("span", null, "em branco"))
        : null
    ),
    h(
      "p",
      { class: "note" },
      "Estimativa simplificada no modelo TRI de 3 parâmetros, com dificuldade média para todas as questões. A nota oficial do INEP pesa cada item pela sua dificuldade e pela coerência das respostas, então use este número só como referência."
    ),
    h(
      "div",
      { class: "nav spaced" },
      h("button", { class: "btn primary", onclick: corr }, "Ver correções"),
      h(
        "button",
        { class: "btn", onclick: () => T.back() },
        T.back === home ? "Novo simulado" : "Voltar ao tópico"
      )
    )
  );
}

/* ============================= Correções ============================= */

function corr() {
  mount(
    h(
      "div",
      { class: "top" },
      h("h2", { class: "brand" }, "Correções"),
      h("button", { class: "btn", onclick: result }, "Voltar ao resultado")
    ),
    T.qs.map((q, j) => {
      const u = T.ans[q.id];
      const ok = u === q.gab;
      return h(
        "section",
        { class: "cor" },
        h(
          "p",
          { class: "meta" },
          "Questão " +
            (j + 1) +
            (q._ok ? " · " + IX.top[q.topico].nome : "") +
            (q.lang ? " · " + (q.lang === "ingles" ? "Inglês" : "Espanhol") : "")
        ),
        h(
          "div",
          { class: "cor-head" },
          h(
            "span",
            { class: "tag " + (u ? (ok ? "ok" : "bad") : "nil") },
            u ? (ok ? "Acertou" : "Errou") : "Em branco"
          )
        ),
        rich(q.enunciado),
        imgs(q),
        h(
          "div",
          { class: "alts" },
          Object.entries(q.alts).map(([l, t]) =>
            h(
              "div",
              { class: "alt" + (l === q.gab ? " gab" : l === u ? " err" : "") },
              h("span", { class: "bub" }, l),
              h(
                "span",
                null,
                altc(t),
                l === q.gab
                  ? h("span", { class: "gab-label" }, " · gabarito")
                  : l === u
                    ? h("span", { class: "gab-label" }, " · sua resposta")
                    : null
              )
            )
          )
        ),
        q.resolucao
          ? [h("h3", null, "Resolução"), h("div", { class: "enun" }, q.resolucao)]
          : h("p", { class: "note" }, "Resolução ainda não cadastrada para esta questão.")
      );
    })
  );
}

/* =========================== Navegação =============================== */

document.addEventListener("keydown", (e) => {
  if (!T || !T.live || e.metaKey || e.ctrlKey || e.altKey) return;
  if (e.target instanceof Element && e.target.matches("input, select, textarea")) return;
  if (e.key === "ArrowRight" && T.i < T.qs.length - 1) {
    T.i += 1;
    test();
  } else if (e.key === "ArrowLeft" && T.i > 0) {
    T.i -= 1;
    test();
  }
});

load();

/* =========================== Modo offline =========================== */

if (
  "serviceWorker" in navigator &&
  (location.protocol === "https:" ||
    location.hostname === "localhost" ||
    location.hostname === "127.0.0.1")
) {
  addEventListener("load", () => {
    navigator.serviceWorker.register("sw.js").catch(() => {
      /* offline é opcional: falha de registro não pode quebrar o app */
    });
  });
}
